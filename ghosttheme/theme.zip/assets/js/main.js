const menuButton = document.querySelector('.burger');
const menu = document.querySelector(
  '.mobile-menu'
);
let showMenu = false;
menuButton.addEventListener('click', toggolmenu);

function toggolmenu() {
  showMenu = !showMenu;
  menu.style.display = showMenu ? 'block' : 'none';
}
